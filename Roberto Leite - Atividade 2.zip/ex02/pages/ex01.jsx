function geraLista(){
    const Lista=[
    <span><h1>1, 2, 3, 4, 5, 6, 7, 8, 9, 10</h1></span>
    ]
    return Lista
}

export default function Lista() {
    return(
        <div>
            {geraLista()}
        </div>
    )
}