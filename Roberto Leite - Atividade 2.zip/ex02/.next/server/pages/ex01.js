"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/ex01";
exports.ids = ["pages/ex01"];
exports.modules = {

/***/ "./pages/ex01.jsx":
/*!************************!*\
  !*** ./pages/ex01.jsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Lista)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\nvar _jsxFileName = \"D:\\\\Meus Documentos\\\\Documentos\\\\Programa\\xE7\\xE3o WEB\\\\ex02\\\\pages\\\\ex01.jsx\";\n\n\nfunction geraLista() {\n  const Lista = [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n      children: \"1, 2, 3, 4, 5, 6, 7, 8, 9, 10\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 3,\n      columnNumber: 11\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 3,\n    columnNumber: 5\n  }, this)];\n  return Lista;\n}\n\nfunction Lista() {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n    children: geraLista()\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 10,\n    columnNumber: 9\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9leDAxLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxTQUFTQSxTQUFULEdBQW9CO0FBQ2hCLFFBQU1DLEtBQUssR0FBQyxjQUNaO0FBQUEsMkJBQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRFksQ0FBWjtBQUdBLFNBQU9BLEtBQVA7QUFDSDs7QUFFYyxTQUFTQSxLQUFULEdBQWlCO0FBQzVCLHNCQUNJO0FBQUEsY0FDS0QsU0FBUztBQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFESjtBQUtIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZXgwMi8uL3BhZ2VzL2V4MDEuanN4P2E5MmIiXSwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gZ2VyYUxpc3RhKCl7XHJcbiAgICBjb25zdCBMaXN0YT1bXHJcbiAgICA8c3Bhbj48aDE+MSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTA8L2gxPjwvc3Bhbj5cclxuICAgIF1cclxuICAgIHJldHVybiBMaXN0YVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaXN0YSgpIHtcclxuICAgIHJldHVybihcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICB7Z2VyYUxpc3RhKCl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn0iXSwibmFtZXMiOlsiZ2VyYUxpc3RhIiwiTGlzdGEiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/ex01.jsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/ex01.jsx"));
module.exports = __webpack_exports__;

})();